package com.example.azureclone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AzureCloneApplication {

    public static void main(String[] args) {
        SpringApplication.run(AzureCloneApplication.class, args);
    }
}
