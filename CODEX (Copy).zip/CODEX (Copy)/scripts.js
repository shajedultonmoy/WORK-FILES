document.addEventListener('DOMContentLoaded', () => {
    const homeSection = document.getElementById('home');
    const servicesSection = document.getElementById('services');
    const contactSection = document.getElementById('contact');

    function showSection(section) {
        homeSection.classList.remove('active');
        servicesSection.classList.remove('active');
        contactSection.classList.remove('active');
        section.classList.add('active');
    }

    document.querySelector('.links a[href="/"]').addEventListener('click', (e) => {
        e.preventDefault();
        showSection(homeSection);
    });

    document.querySelector('.links a[href="/services"]').addEventListener('click', (e) => {
        e.preventDefault();
        showSection(servicesSection);
    });

    document.querySelector('.links a[href="/contact"]').addEventListener('click', (e) => {
        e.preventDefault();
        showSection(contactSection);
    });

    // Show the home section by default
    showSection(homeSection);
});
